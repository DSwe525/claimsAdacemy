package LabAbstraction;

public interface Bills {
    
    public abstract double gasBill();

    public abstract double carInsurance();
}
