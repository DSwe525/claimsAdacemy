package LabAbstraction;

public class School {
    
}
